Synthetic DFT frontend demonstration only. No calculation or measured data.
