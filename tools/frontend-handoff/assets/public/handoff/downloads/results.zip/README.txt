Synthetic frontend demonstration only. No calculation or measured data.
